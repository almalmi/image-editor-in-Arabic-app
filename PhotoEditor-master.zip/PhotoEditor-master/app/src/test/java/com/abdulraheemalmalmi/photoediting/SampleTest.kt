package com.abdulraheemalmalmi.photoediting

import junit.framework.TestCase.assertEquals
import org.junit.Test

class SampleTest {
    @Test
    fun testAddition() {
        assertEquals(6, (3 + 3).toLong())
    }
}