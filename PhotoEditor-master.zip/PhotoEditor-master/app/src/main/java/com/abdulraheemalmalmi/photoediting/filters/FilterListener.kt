package com.abdulraheemalmalmi.photoediting.filters

import ja.abdulraheemalmalmi.photoeditor.PhotoFilter

interface FilterListener {
    fun onFilterSelected(photoFilter: PhotoFilter?)
}