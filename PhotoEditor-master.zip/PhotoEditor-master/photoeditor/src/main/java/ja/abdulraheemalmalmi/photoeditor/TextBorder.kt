package ja.abdulraheemalmalmi.photoeditor

class TextBorder(
    var corner: Float,
    var backGroundColor: Int,
    var strokeWidth: Int,
    var strokeColor: Int
)